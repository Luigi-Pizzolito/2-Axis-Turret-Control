var port = 8080,
	WebSocketServer = require('ws').Server,
	wss = new WebSocketServer({
		port: port
	});

const SerialPort = require('serialport');
const sport = new SerialPort('/dev/cu.usbmodem1411', { baudRate: 115200 })

console.log('listening on port: ' + port);

wss.on('connection', function connection(ws) {

	ws.on('message', function (message) {

		console.log('message: ' + message);
		ws.send('echo: ' + message);

		console.log("Pitch: " + message.substring(0, message.indexOf(",")));
		console.log("Yaw: " + message.split(',').pop().split('.')[0] );

		sport.write(message);

	});

	console.log('new client connected!');
	ws.send('connected!');

});